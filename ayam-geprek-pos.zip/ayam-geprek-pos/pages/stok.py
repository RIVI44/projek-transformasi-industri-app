import streamlit as st
import pandas as pd
from utils.database import get_supabase
from utils.helpers import format_rupiah


def show():
    supabase = get_supabase()

    st.markdown("## 📦 Manajemen Stok")
    st.markdown("Pantau dan update stok bahan baku.")
    st.markdown("---")

    tab1, tab2, tab3 = st.tabs(["📋 Stok Bahan Baku", "🍽️ Kelola Menu", "➕ Tambah Bahan"])

    # ── TAB 1: Stok Bahan Baku ─────────────────────────────────────────
    with tab1:
        try:
            res = supabase.table("stok").select("*").order("nama_bahan").execute()
            stok_data = res.data
        except Exception as e:
            st.error(f"Gagal memuat stok: {e}")
            return

        if not stok_data:
            st.info("Belum ada data stok.")
            return

        # Summary cards
        total_bahan = len(stok_data)
        kritis = [s for s in stok_data if s["stok_saat_ini"] <= s["stok_minimum"]]
        aman = [s for s in stok_data if s["stok_saat_ini"] > s["stok_minimum"]]

        c1, c2, c3 = st.columns(3)
        c1.metric("Total Bahan", total_bahan)
        c2.metric("✅ Stok Aman", len(aman))
        c3.metric("⚠️ Stok Kritis", len(kritis), delta=f"-{len(kritis)}" if kritis else None, delta_color="inverse")

        st.markdown("---")

        # Tabel stok dengan warna status
        df = pd.DataFrame(stok_data)

        def status_stok(row):
            if row["stok_saat_ini"] <= 0:
                return "🔴 Habis"
            elif row["stok_saat_ini"] <= row["stok_minimum"]:
                return "🟡 Hampir Habis"
            else:
                return "🟢 Aman"

        df["status"] = df.apply(status_stok, axis=1)
        df_show = df[["nama_bahan", "stok_saat_ini", "satuan", "stok_minimum", "status"]].copy()
        df_show.columns = ["Nama Bahan", "Stok Saat Ini", "Satuan", "Stok Minimum", "Status"]

        st.dataframe(df_show, use_container_width=True, hide_index=True)

        # Update stok
        st.markdown("### ✏️ Update Stok")
        bahan_options = {s["nama_bahan"]: s for s in stok_data}
        selected = st.selectbox("Pilih Bahan", list(bahan_options.keys()))

        if selected:
            item = bahan_options[selected]
            col_a, col_b = st.columns(2)
            with col_a:
                st.info(f"Stok saat ini: **{item['stok_saat_ini']} {item['satuan']}**")
            with col_b:
                aksi = st.radio("Aksi", ["Tambah Stok", "Set Stok Baru"], horizontal=True)

            jumlah = st.number_input(
                f"Jumlah ({item['satuan']})",
                min_value=0.0, step=0.5, value=1.0
            )

            if st.button("💾 Simpan Perubahan", type="primary"):
                try:
                    if aksi == "Tambah Stok":
                        stok_baru = item["stok_saat_ini"] + jumlah
                    else:
                        stok_baru = jumlah

                    supabase.table("stok").update({
                        "stok_saat_ini": stok_baru,
                        "updated_at": "now()"
                    }).eq("id", item["id"]).execute()

                    st.success(f"✅ Stok **{selected}** diperbarui: {stok_baru} {item['satuan']}")
                    st.rerun()
                except Exception as e:
                    st.error(f"Gagal update: {e}")

    # ── TAB 2: Kelola Menu ─────────────────────────────────────────────
    with tab2:
        try:
            res_menu = supabase.table("menu").select("*").order("kategori").execute()
            menu_data = res_menu.data
        except Exception as e:
            st.error(f"Gagal memuat menu: {e}")
            return

        st.markdown("### 📋 Daftar Menu")
        df_menu = pd.DataFrame(menu_data)
        if not df_menu.empty:
            df_menu["harga_fmt"] = df_menu["harga"].apply(format_rupiah)
            df_menu["tersedia"] = df_menu["tersedia"].map({True: "✅ Aktif", False: "❌ Nonaktif"})
            st.dataframe(
                df_menu[["nama", "kategori", "harga_fmt", "tersedia"]],
                column_config={
                    "nama": "Nama Menu",
                    "kategori": "Kategori",
                    "harga_fmt": "Harga",
                    "tersedia": "Status"
                },
                use_container_width=True, hide_index=True
            )

        st.markdown("### ➕ Tambah / Edit Menu")
        col1, col2 = st.columns(2)
        with col1:
            nama_menu = st.text_input("Nama Menu")
            harga_menu = st.number_input("Harga (Rp)", min_value=0, step=500)
        with col2:
            kat_menu = st.selectbox("Kategori", ["Ayam", "Nasi", "Minuman", "Lauk", "Lainnya"])
            tersedia = st.checkbox("Tersedia / Aktif", value=True)

        if st.button("💾 Simpan Menu", type="primary"):
            if nama_menu and harga_menu > 0:
                try:
                    supabase.table("menu").insert({
                        "nama": nama_menu,
                        "kategori": kat_menu,
                        "harga": harga_menu,
                        "tersedia": tersedia
                    }).execute()
                    st.success(f"✅ Menu **{nama_menu}** berhasil ditambahkan!")
                    st.rerun()
                except Exception as e:
                    st.error(f"Gagal: {e}")
            else:
                st.warning("Nama menu dan harga harus diisi.")

    # ── TAB 3: Tambah Bahan ────────────────────────────────────────────
    with tab3:
        st.markdown("### ➕ Tambah Bahan Baru")
        col1, col2 = st.columns(2)
        with col1:
            nama_bahan = st.text_input("Nama Bahan")
            satuan = st.selectbox("Satuan", ["kg", "gram", "liter", "ml", "pcs", "butir", "ikat", "bungkus"])
        with col2:
            stok_awal = st.number_input("Stok Awal", min_value=0.0, step=0.5)
            stok_min = st.number_input("Stok Minimum (alert)", min_value=0.0, step=0.5)

        if st.button("💾 Tambah Bahan", type="primary"):
            if nama_bahan:
                try:
                    supabase.table("stok").insert({
                        "nama_bahan": nama_bahan,
                        "satuan": satuan,
                        "stok_saat_ini": stok_awal,
                        "stok_minimum": stok_min
                    }).execute()
                    st.success(f"✅ Bahan **{nama_bahan}** berhasil ditambahkan!")
                    st.rerun()
                except Exception as e:
                    st.error(f"Gagal: {e}")
            else:
                st.warning("Nama bahan harus diisi.")
