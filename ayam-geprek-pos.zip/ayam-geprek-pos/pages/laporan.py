import streamlit as st
import pandas as pd
from datetime import date, timedelta
from utils.database import get_supabase
from utils.helpers import format_rupiah


def show():
    supabase = get_supabase()

    st.markdown("## 📊 Laporan Penjualan")
    st.markdown("Analisis real-time omset dan performa menu.")
    st.markdown("---")

    # ── Filter Tanggal ─────────────────────────────────────────────────
    col_f1, col_f2, col_f3 = st.columns([2, 2, 1])
    with col_f1:
        tgl_awal = st.date_input("Dari Tanggal", value=date.today() - timedelta(days=7))
    with col_f2:
        tgl_akhir = st.date_input("Sampai Tanggal", value=date.today())
    with col_f3:
        st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
        refresh = st.button("🔄 Refresh", use_container_width=True)

    if tgl_awal > tgl_akhir:
        st.error("Tanggal awal tidak boleh lebih besar dari tanggal akhir.")
        return

    # ── Fetch Data ─────────────────────────────────────────────────────
    try:
        res_trx = supabase.table("transaksi") \
            .select("*") \
            .gte("created_at", f"{tgl_awal}T00:00:00") \
            .lte("created_at", f"{tgl_akhir}T23:59:59") \
            .order("created_at", desc=True) \
            .execute()
        trx_list = res_trx.data

        res_detail = supabase.table("detail_transaksi") \
            .select("*, transaksi(created_at)") \
            .execute()

        # Filter detail sesuai rentang
        detail_list = [
            d for d in res_detail.data
            if d.get("transaksi") and
            tgl_awal.isoformat() <= d["transaksi"]["created_at"][:10] <= tgl_akhir.isoformat()
        ]

    except Exception as e:
        st.error(f"Gagal memuat laporan: {e}")
        return

    if not trx_list:
        st.info("Tidak ada transaksi pada periode yang dipilih.")
        return

    # ── Summary Metrics ────────────────────────────────────────────────
    total_omset = sum(t["total"] for t in trx_list)
    total_trx = len(trx_list)
    avg_trx = total_omset // total_trx if total_trx > 0 else 0
    total_item = sum(d["qty"] for d in detail_list)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("💰 Total Omset", format_rupiah(total_omset))
    c2.metric("🧾 Jumlah Transaksi", total_trx)
    c3.metric("📈 Rata-rata/Transaksi", format_rupiah(avg_trx))
    c4.metric("🍗 Item Terjual", total_item)

    st.markdown("---")

    # ── Grafik & Tabel ─────────────────────────────────────────────────
    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown("### 📈 Omset per Hari")
        df_trx = pd.DataFrame(trx_list)
        df_trx["tanggal"] = pd.to_datetime(df_trx["created_at"]).dt.date
        omset_harian = df_trx.groupby("tanggal")["total"].sum().reset_index()
        omset_harian.columns = ["Tanggal", "Omset (Rp)"]
        omset_harian = omset_harian.set_index("Tanggal")
        st.bar_chart(omset_harian, color="#ff6b00")

    with col_r:
        st.markdown("### 💳 Metode Pembayaran")
        metode_count = df_trx["metode_bayar"].value_counts().reset_index()
        metode_count.columns = ["Metode", "Jumlah"]
        st.dataframe(metode_count, use_container_width=True, hide_index=True)

        st.markdown("### ⏰ Jam Tersibuk")
        df_trx["jam"] = pd.to_datetime(df_trx["created_at"]).dt.hour
        jam_count = df_trx.groupby("jam").size().reset_index(name="Transaksi")
        jam_count["Jam"] = jam_count["jam"].apply(lambda h: f"{h:02d}:00")
        if not jam_count.empty:
            peak = jam_count.loc[jam_count["Transaksi"].idxmax()]
            st.info(f"🔥 Jam paling ramai: **{peak['Jam']}** ({peak['Transaksi']} transaksi)")

    st.markdown("---")

    # ── Menu Terlaris ──────────────────────────────────────────────────
    st.markdown("### 🏆 Menu Terlaris")
    if detail_list:
        df_detail = pd.DataFrame(detail_list)
        menu_laris = df_detail.groupby("nama_menu").agg(
            Total_Qty=("qty", "sum"),
            Total_Pendapatan=("subtotal", "sum")
        ).sort_values("Total_Qty", ascending=False).reset_index()
        menu_laris["Total_Pendapatan"] = menu_laris["Total_Pendapatan"].apply(format_rupiah)
        menu_laris.columns = ["Nama Menu", "Qty Terjual", "Total Pendapatan"]

        col_rank, col_chart = st.columns([2, 3])
        with col_rank:
            st.dataframe(menu_laris, use_container_width=True, hide_index=True)
        with col_chart:
            top5 = df_detail.groupby("nama_menu")["qty"].sum().nlargest(5)
            st.bar_chart(top5, color="#ff9a00")

    st.markdown("---")

    # ── Riwayat Transaksi ──────────────────────────────────────────────
    st.markdown("### 🧾 Riwayat Transaksi")
    df_show = df_trx[["nomor_order", "total", "metode_bayar", "status", "created_at"]].copy()
    df_show["total"] = df_show["total"].apply(format_rupiah)
    df_show["created_at"] = pd.to_datetime(df_show["created_at"]).dt.strftime("%d/%m/%Y %H:%M")
    df_show.columns = ["No. Order", "Total", "Pembayaran", "Status", "Waktu"]
    st.dataframe(df_show, use_container_width=True, hide_index=True)

    # Export CSV
    csv = df_show.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download CSV",
        csv,
        file_name=f"laporan_{tgl_awal}_{tgl_akhir}.csv",
        mime="text/csv"
    )
