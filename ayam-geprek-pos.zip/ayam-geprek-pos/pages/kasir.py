import streamlit as st
import pandas as pd
from utils.database import get_supabase
from utils.helpers import format_rupiah, generate_order_number


def show():
    supabase = get_supabase()

    st.markdown("## 🛒 Kasir")
    st.markdown("Pilih menu, atur quantity, lalu proses pembayaran.")
    st.markdown("---")

    # Init session state keranjang
    if "keranjang" not in st.session_state:
        st.session_state.keranjang = []

    # ── Load menu ──────────────────────────────────────────────────────
    try:
        res_menu = supabase.table("menu") \
            .select("*") \
            .eq("tersedia", True) \
            .order("kategori") \
            .execute()
        menu_data = res_menu.data
    except Exception as e:
        st.error(f"Gagal memuat menu: {e}")
        return

    # ── Layout: Menu kiri, Keranjang kanan ────────────────────────────
    col_menu, col_cart = st.columns([3, 2])

    with col_menu:
        st.markdown("### 🍽️ Daftar Menu")

        # Filter kategori
        kategori_list = sorted(set(m["kategori"] for m in menu_data))
        tab_list = st.tabs(kategori_list)

        for tab, kat in zip(tab_list, kategori_list):
            with tab:
                items = [m for m in menu_data if m["kategori"] == kat]
                cols = st.columns(2)
                for i, item in enumerate(items):
                    with cols[i % 2]:
                        with st.container(border=True):
                            st.markdown(f"**{item['nama']}**")
                            st.markdown(f"<span style='color:#ff9a3c;font-weight:700'>{format_rupiah(item['harga'])}</span>",
                                        unsafe_allow_html=True)
                            qty_key = f"qty_{item['id']}"
                            qty = st.number_input("Qty", min_value=0, max_value=50,
                                                  value=0, key=qty_key, label_visibility="collapsed")
                            if st.button("➕ Tambah", key=f"add_{item['id']}", use_container_width=True):
                                if qty > 0:
                                    # Cek apakah sudah ada di keranjang
                                    found = False
                                    for k in st.session_state.keranjang:
                                        if k["menu_id"] == item["id"]:
                                            k["qty"] += qty
                                            k["subtotal"] = k["qty"] * k["harga"]
                                            found = True
                                            break
                                    if not found:
                                        st.session_state.keranjang.append({
                                            "menu_id": item["id"],
                                            "nama": item["nama"],
                                            "harga": item["harga"],
                                            "qty": qty,
                                            "subtotal": item["harga"] * qty
                                        })
                                    st.success(f"✅ {item['nama']} x{qty} ditambahkan!")
                                    st.rerun()
                                else:
                                    st.warning("Qty harus > 0")

    with col_cart:
        st.markdown("### 🧺 Keranjang")

        if not st.session_state.keranjang:
            st.info("Keranjang kosong. Pilih menu di sebelah kiri.")
        else:
            # Tampilkan keranjang
            for idx, item in enumerate(st.session_state.keranjang):
                with st.container(border=True):
                    c1, c2, c3 = st.columns([3, 1, 1])
                    with c1:
                        st.markdown(f"**{item['nama']}**")
                        st.caption(f"{format_rupiah(item['harga'])} × {item['qty']}")
                    with c2:
                        st.markdown(f"<div style='color:#ff9a3c;font-weight:700;padding-top:10px'>"
                                    f"{format_rupiah(item['subtotal'])}</div>",
                                    unsafe_allow_html=True)
                    with c3:
                        if st.button("🗑️", key=f"del_{idx}"):
                            st.session_state.keranjang.pop(idx)
                            st.rerun()

            st.markdown("---")
            total = sum(i["subtotal"] for i in st.session_state.keranjang)
            st.markdown(f"### Total: <span style='color:#ff9a3c'>{format_rupiah(total)}</span>",
                        unsafe_allow_html=True)

            # Pembayaran
            st.markdown("#### 💳 Pembayaran")
            metode = st.selectbox("Metode Bayar", ["Tunai", "QRIS", "Transfer Bank", "Kartu Debit"])

            uang_bayar = 0
            kembalian = 0
            if metode == "Tunai":
                uang_bayar = st.number_input("Uang Bayar (Rp)", min_value=0, step=1000, value=total)
                kembalian = max(0, uang_bayar - total)
                if kembalian > 0:
                    st.success(f"💵 Kembalian: **{format_rupiah(kembalian)}**")
                elif uang_bayar < total:
                    st.error(f"❌ Uang kurang {format_rupiah(total - uang_bayar)}")

            col_bayar, col_reset = st.columns(2)

            with col_bayar:
                bayar_ok = metode != "Tunai" or uang_bayar >= total
                if st.button("✅ Bayar Sekarang", type="primary", use_container_width=True,
                             disabled=not bayar_ok):
                    try:
                        nomor = generate_order_number()
                        # Insert transaksi
                        res = supabase.table("transaksi").insert({
                            "nomor_order": nomor,
                            "total": total,
                            "metode_bayar": metode,
                            "uang_bayar": uang_bayar,
                            "kembalian": kembalian,
                            "status": "selesai"
                        }).execute()

                        trx_id = res.data[0]["id"]

                        # Insert detail
                        details = [{
                            "transaksi_id": trx_id,
                            "menu_id": item["menu_id"],
                            "nama_menu": item["nama"],
                            "harga": item["harga"],
                            "qty": item["qty"],
                            "subtotal": item["subtotal"]
                        } for item in st.session_state.keranjang]

                        supabase.table("detail_transaksi").insert(details).execute()

                        # Reset keranjang
                        st.session_state.keranjang = []
                        st.success(f"🎉 Transaksi **{nomor}** berhasil! Total: {format_rupiah(total)}")
                        st.balloons()
                        st.rerun()

                    except Exception as e:
                        st.error(f"Gagal menyimpan transaksi: {e}")

            with col_reset:
                if st.button("🗑️ Kosongkan", use_container_width=True):
                    st.session_state.keranjang = []
                    st.rerun()
