import streamlit as st
import pandas as pd
from datetime import date, timedelta
from utils.database import get_supabase
from utils.helpers import format_rupiah, get_greeting


def show():
    supabase = get_supabase()
    today = date.today().isoformat()
    yesterday = (date.today() - timedelta(days=1)).isoformat()

    st.markdown(f"## 🏠 Dashboard")
    st.markdown(f"**{get_greeting()}, Selamat datang di POS Ayam Geprek!** · {date.today().strftime('%A, %d %B %Y')}")
    st.markdown("---")

    # ── Metrics ──────────────────────────────────────────────────────
    col1, col2, col3, col4 = st.columns(4)

    try:
        # Omset hari ini
        res_today = supabase.table("transaksi") \
            .select("total") \
            .gte("created_at", f"{today}T00:00:00") \
            .lte("created_at", f"{today}T23:59:59") \
            .execute()
        omset_today = sum(r["total"] for r in res_today.data)

        # Omset kemarin
        res_yesterday = supabase.table("transaksi") \
            .select("total") \
            .gte("created_at", f"{yesterday}T00:00:00") \
            .lte("created_at", f"{yesterday}T23:59:59") \
            .execute()
        omset_yesterday = sum(r["total"] for r in res_yesterday.data)

        delta_omset = omset_today - omset_yesterday

        # Total transaksi hari ini
        total_trx = len(res_today.data)

        # Item terjual hari ini
        res_detail = supabase.table("detail_transaksi") \
            .select("qty, transaksi_id, transaksi(created_at)") \
            .execute()
        item_today = sum(
            r["qty"] for r in res_detail.data
            if r.get("transaksi") and r["transaksi"]["created_at"].startswith(today)
        )

        # Stok hampir habis
        res_stok = supabase.table("stok").select("*").execute()
        stok_kritis = sum(
            1 for s in res_stok.data
            if s["stok_saat_ini"] <= s["stok_minimum"]
        )

    except Exception as e:
        st.error(f"Gagal memuat data: {e}")
        omset_today = omset_yesterday = total_trx = item_today = stok_kritis = 0
        delta_omset = 0

    with col1:
        st.metric("💰 Omset Hari Ini", format_rupiah(omset_today),
                  delta=format_rupiah(delta_omset) if delta_omset != 0 else None)
    with col2:
        st.metric("🧾 Transaksi", f"{total_trx} order")
    with col3:
        avg = omset_today // total_trx if total_trx > 0 else 0
        st.metric("📈 Rata-rata/Order", format_rupiah(avg))
    with col4:
        st.metric("⚠️ Stok Kritis", f"{stok_kritis} bahan",
                  delta=f"-{stok_kritis} perlu restok" if stok_kritis > 0 else None,
                  delta_color="inverse")

    st.markdown("---")

    # ── Grafik & Tabel ────────────────────────────────────────────────
    col_left, col_right = st.columns([3, 2])

    with col_left:
        st.markdown("### 📈 Omset 7 Hari Terakhir")
        try:
            dates = [(date.today() - timedelta(days=i)) for i in range(6, -1, -1)]
            omset_list = []
            for d in dates:
                d_str = d.isoformat()
                res = supabase.table("transaksi") \
                    .select("total") \
                    .gte("created_at", f"{d_str}T00:00:00") \
                    .lte("created_at", f"{d_str}T23:59:59") \
                    .execute()
                omset_list.append(sum(r["total"] for r in res.data))

            df_chart = pd.DataFrame({
                "Tanggal": [d.strftime("%d/%m") for d in dates],
                "Omset (Rp)": omset_list
            }).set_index("Tanggal")
            st.bar_chart(df_chart, color="#ff6b00")
        except Exception as e:
            st.info("Belum ada data transaksi untuk grafik.")

    with col_right:
        st.markdown("### ⚠️ Stok Hampir Habis")
        try:
            kritis = [s for s in res_stok.data if s["stok_saat_ini"] <= s["stok_minimum"]]
            if kritis:
                df_kritis = pd.DataFrame(kritis)[["nama_bahan", "stok_saat_ini", "satuan", "stok_minimum"]]
                df_kritis.columns = ["Bahan", "Stok", "Satuan", "Min."]
                st.dataframe(df_kritis, use_container_width=True, hide_index=True)
            else:
                st.success("✅ Semua stok aman!")
        except:
            st.info("Tidak ada data stok.")

    # ── Transaksi Terbaru ─────────────────────────────────────────────
    st.markdown("### 🧾 Transaksi Terbaru Hari Ini")
    try:
        res_trx = supabase.table("transaksi") \
            .select("*") \
            .gte("created_at", f"{today}T00:00:00") \
            .order("created_at", desc=True) \
            .limit(10) \
            .execute()
        if res_trx.data:
            df_trx = pd.DataFrame(res_trx.data)
            df_trx["total"] = df_trx["total"].apply(format_rupiah)
            df_trx["created_at"] = pd.to_datetime(df_trx["created_at"]).dt.strftime("%H:%M")
            df_trx = df_trx[["nomor_order", "total", "metode_bayar", "status", "created_at"]]
            df_trx.columns = ["No. Order", "Total", "Pembayaran", "Status", "Jam"]
            st.dataframe(df_trx, use_container_width=True, hide_index=True)
        else:
            st.info("Belum ada transaksi hari ini.")
    except Exception as e:
        st.error(f"Error: {e}")
