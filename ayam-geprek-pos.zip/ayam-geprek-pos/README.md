# 🍗 POS Ayam Geprek — Cloud Point of Sale

Aplikasi kasir berbasis cloud untuk usaha Ayam Geprek. Dibangun dengan **Streamlit** + **Supabase** (PostgreSQL).

## ✨ Fitur
| Fitur | Keterangan |
|---|---|
| 🏠 Dashboard | Omset harian, grafik 7 hari, stok kritis |
| 🛒 Kasir | Pilih menu per kategori, keranjang, hitung kembalian |
| 📦 Stok | Monitor bahan baku, update stok, kelola menu |
| 📊 Laporan | Filter tanggal, menu terlaris, export CSV |

---

## 🚀 Cara Deploy (GitHub → Streamlit Cloud)

### Langkah 1 — Setup Supabase

1. Daftar gratis di [supabase.com](https://supabase.com)
2. Buat project baru
3. Buka **SQL Editor**, paste isi dari `utils/database.py` (fungsi `init_database()`)
4. Klik **Run** → tabel dan data awal akan terbuat otomatis
5. Catat **Project URL** dan **anon public key** dari *Settings > API*

### Langkah 2 — Push ke GitHub

```bash
git init
git add .
git commit -m "🍗 Initial commit POS Ayam Geprek"
git remote add origin https://github.com/USERNAME/pos-ayam-geprek.git
git push -u origin main
```

> ⚠️ Pastikan `.streamlit/secrets.toml` **TIDAK** ikut di-push (sudah ada di `.gitignore`)

### Langkah 3 — Deploy ke Streamlit Cloud

1. Buka [share.streamlit.io](https://share.streamlit.io)
2. Klik **New app**
3. Pilih repo GitHub kamu
4. Main file path: `app.py`
5. Klik **Advanced settings > Secrets**, isi:

```toml
SUPABASE_URL = "https://xxxxxxxxxxxx.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.xxxxxxxx"
```

6. Klik **Deploy!** 🎉

---

## 🗂️ Struktur Project

```
pos-ayam-geprek/
├── app.py                  # Entry point utama
├── requirements.txt        # Dependency Python
├── .gitignore
├── .streamlit/
│   └── secrets.toml.example
├── pages/
│   ├── dashboard.py        # Halaman dashboard
│   ├── kasir.py            # Halaman kasir/POS
│   ├── stok.py             # Manajemen stok & menu
│   └── laporan.py          # Laporan & analisis
└── utils/
    ├── database.py         # Koneksi Supabase + schema SQL
    └── helpers.py          # Fungsi bantu (format Rupiah, dll)
```

---

## 💻 Jalankan Lokal

```bash
# Clone repo
git clone https://github.com/USERNAME/pos-ayam-geprek.git
cd pos-ayam-geprek

# Install dependency
pip install -r requirements.txt

# Buat file secrets
mkdir .streamlit
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# Edit secrets.toml, isi URL dan KEY Supabase kamu

# Jalankan
streamlit run app.py
```

---

## 🛠️ Tech Stack

- **Frontend**: Streamlit (Python)
- **Database**: Supabase (PostgreSQL cloud)
- **Deploy**: Streamlit Community Cloud (gratis)
- **Repo**: GitHub
