import streamlit as st
from supabase import create_client, Client
import os

@st.cache_resource
def get_supabase() -> Client:
    """Initialize Supabase client using Streamlit secrets."""
    url = st.secrets["SUPABASE_URL"]
    key = st.secrets["SUPABASE_KEY"]
    return create_client(url, key)


def init_database():
    """
    SQL schema — jalankan sekali di Supabase SQL Editor.
    Tidak perlu dijalankan ulang setelah tabel ada.
    """
    schema = """
    -- Tabel Menu
    CREATE TABLE IF NOT EXISTS menu (
        id          SERIAL PRIMARY KEY,
        nama        TEXT NOT NULL,
        kategori    TEXT NOT NULL,
        harga       INTEGER NOT NULL,
        tersedia    BOOLEAN DEFAULT TRUE,
        created_at  TIMESTAMPTZ DEFAULT NOW()
    );

    -- Tabel Stok Bahan
    CREATE TABLE IF NOT EXISTS stok (
        id          SERIAL PRIMARY KEY,
        nama_bahan  TEXT NOT NULL,
        satuan      TEXT NOT NULL,
        stok_saat_ini NUMERIC(10,2) DEFAULT 0,
        stok_minimum  NUMERIC(10,2) DEFAULT 0,
        updated_at  TIMESTAMPTZ DEFAULT NOW()
    );

    -- Tabel Transaksi
    CREATE TABLE IF NOT EXISTS transaksi (
        id              SERIAL PRIMARY KEY,
        nomor_order     TEXT NOT NULL UNIQUE,
        total           INTEGER NOT NULL,
        metode_bayar    TEXT NOT NULL,
        uang_bayar      INTEGER DEFAULT 0,
        kembalian       INTEGER DEFAULT 0,
        status          TEXT DEFAULT 'selesai',
        created_at      TIMESTAMPTZ DEFAULT NOW()
    );

    -- Tabel Detail Transaksi
    CREATE TABLE IF NOT EXISTS detail_transaksi (
        id              SERIAL PRIMARY KEY,
        transaksi_id    INTEGER REFERENCES transaksi(id) ON DELETE CASCADE,
        menu_id         INTEGER REFERENCES menu(id),
        nama_menu       TEXT NOT NULL,
        harga           INTEGER NOT NULL,
        qty             INTEGER NOT NULL,
        subtotal        INTEGER NOT NULL
    );

    -- Seed data menu awal
    INSERT INTO menu (nama, kategori, harga) VALUES
        ('Ayam Geprek Original',   'Ayam', 15000),
        ('Ayam Geprek Keju',       'Ayam', 20000),
        ('Ayam Geprek Mozarela',   'Ayam', 22000),
        ('Ayam Geprek Pedas Gila', 'Ayam', 17000),
        ('Nasi Putih',             'Nasi', 3000),
        ('Nasi Uduk',              'Nasi', 5000),
        ('Es Teh Manis',           'Minuman', 5000),
        ('Es Jeruk',               'Minuman', 7000),
        ('Air Mineral',            'Minuman', 4000),
        ('Tahu Goreng',            'Lauk', 3000),
        ('Tempe Goreng',           'Lauk', 3000),
        ('Telur Dadar',            'Lauk', 5000)
    ON CONFLICT DO NOTHING;

    -- Seed data stok awal
    INSERT INTO stok (nama_bahan, satuan, stok_saat_ini, stok_minimum) VALUES
        ('Ayam Potong',    'kg',  20, 5),
        ('Tepung Bumbu',   'kg',  10, 2),
        ('Minyak Goreng',  'liter', 15, 3),
        ('Beras',          'kg',  30, 10),
        ('Cabai Merah',    'kg',  5,  1),
        ('Bawang Putih',   'kg',  3,  0.5),
        ('Keju Slice',     'pcs', 50, 10),
        ('Tahu',           'pcs', 40, 10),
        ('Tempe',          'pcs', 30, 10),
        ('Telur',          'butir', 60, 20)
    ON CONFLICT DO NOTHING;
    """
    return schema
