from datetime import datetime
import random
import string


def format_rupiah(amount: int) -> str:
    """Format angka ke format Rupiah Indonesia."""
    return f"Rp {amount:,.0f}".replace(",", ".")


def generate_order_number() -> str:
    """Generate nomor order unik: ORD-YYYYMMDD-XXXX"""
    now = datetime.now()
    suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    return f"ORD-{now.strftime('%Y%m%d')}-{suffix}"


def get_greeting() -> str:
    hour = datetime.now().hour
    if hour < 11:
        return "Selamat Pagi"
    elif hour < 15:
        return "Selamat Siang"
    elif hour < 18:
        return "Selamat Sore"
    else:
        return "Selamat Malam"
